
# WORKOUT AI SCRIPT

import pandas as pd
import numpy as np
import pickle
from sklearn.neighbors import NearestNeighbors

# Exercise dataset
exercise_data = [
    {"name": "Bodyweight Squats", "primary_muscle": "legs", "equipment": "none", 
     "difficulty": "beginner", "time_per_set": 3, "workout_type": "strength", 
     "rep_range": "10-15", "sets": 3, "instructions": "Stand with feet shoulder-width apart..."},
     
    {"name": "Push-ups", "primary_muscle": "chest", "equipment": "none", 
     "difficulty": "beginner", "time_per_set": 3, "workout_type": "strength", 
     "rep_range": "8-12", "sets": 3, "instructions": "Start in plank position..."},
    # Add more exercises here
]

exercise_df = pd.DataFrame(exercise_data)

# WorkoutRecommender class
class WorkoutRecommender:
    def __init__(self, exercise_data):
        self.exercise_data = exercise_data.copy()
        self.processed_data = self._preprocess_data(self.exercise_data)
        self.feature_columns = [col for col in self.processed_data.columns 
                              if col not in ['name', 'rep_range', 'sets', 'instructions']]
        
        n_neighbors = max(1, min(10, len(exercise_data)))
        self.model = NearestNeighbors(n_neighbors=n_neighbors, algorithm='ball_tree')
        self.model.fit(self.processed_data[self.feature_columns])
        
    def _preprocess_data(self, df):
        columns_to_encode = ['primary_muscle', 'equipment', 'difficulty', 'workout_type']
        existing_columns = [col for col in columns_to_encode if col in df.columns]
        
        if existing_columns:
            df_processed = pd.get_dummies(df, columns=existing_columns)
        else:
            df_processed = df.copy()
        
        if 'time_per_set' in df_processed.columns:
            df_processed['time_per_set'] = df_processed['time_per_set'].astype(float)
            min_time = df_processed['time_per_set'].min()
            max_time = df_processed['time_per_set'].max()
            df_processed['time_per_set'] = np.where(
                max_time > min_time,
                (df_processed['time_per_set'] - min_time) / (max_time - min_time),
                0.5
            )
        return df_processed

# Example usage:
# recommender = WorkoutRecommender(exercise_df)
# user_profile = {'goal': 'strength', 'level': 'beginner', ...}
# recommendations = recommender.recommend_workouts(user_profile)
