# Together AI Hydration Advisor

This is a FastAPI project that calculates personalized hydration goals and generates AI-powered advice using Together.ai's `openchat/openchat-3.5-1210` model.

## How to Run

1. Create a virtual environment (optional but recommended):

```bash
python -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the FastAPI server:

```bash
uvicorn main:app --reload
```

4. Open your browser and go to:

```
http://127.0.0.1:8000/docs
```

You can test the `/ai/hydration-goal` endpoint using the interactive Swagger UI.
