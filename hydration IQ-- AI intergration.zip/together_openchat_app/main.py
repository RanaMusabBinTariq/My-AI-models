import requests
import random
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import datetime

app = FastAPI()

# 🔑 API Keys
WEATHER_API_KEY = "1abd54e04598b27a08c1f65af2d7ff2a"
TOGETHER_API_KEY = "61af2e7656babc2a236f7b1602d5cb5a231d547da701b224273ddae2e114620b"
TOGETHER_MODEL = "mistralai/Mistral-7B-Instruct-v0.1"

class HydrationRequest(BaseModel):
    weight: float
    gender: str
    creatine_dosage: float
    activity_level: str
    latitude: float
    longitude: float

# 🤖 Together.ai AI call (Mistral model)
def get_ai_advice(prompt: str) -> str:
    url = "https://api.together.xyz/inference"
    headers = {
        "Authorization": f"Bearer {TOGETHER_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": TOGETHER_MODEL,
        "prompt": prompt,
        "max_tokens": 50,
        "temperature": 0.9,
        "top_p": 0.95,
        "repetition_penalty": 1.0
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        print("🧠 Together.ai status:", response.status_code)
        print("🧠 Together.ai response:", response.text)

        if response.status_code != 200:
            return f"⚠️ Together.ai error {response.status_code}: {response.text}"

        data = response.json()
        return data["output"]["choices"][0]["text"].strip()
    except Exception as e:
        print("❌ Together.ai exception:", e)
        return "⚠️ AI call failed."

# 🚰 Hydration endpoint
@app.post("/ai/hydration-goal")
def calculate_hydration(data: HydrationRequest):
    weather_url = (
        f"http://api.openweathermap.org/data/2.5/weather?"
        f"lat={data.latitude}&lon={data.longitude}&appid={WEATHER_API_KEY}&units=metric"
    )
    response = requests.get(weather_url)
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="Weather API error")

    weather = response.json()
    temp_c = weather.get("main", {}).get("temp")
    humidity = weather.get("main", {}).get("humidity")

    if temp_c is None or humidity is None:
        raise HTTPException(status_code=500, detail="Missing weather data")

    base = max(2000, data.weight * 35) if data.gender.lower() == "female" else max(2500, data.weight * 35)
    temp_adjust = max(0, (temp_c - 20) * 10)
    activity_map = {"low": 0, "moderate": 350, "high": 700}
    activity_adjust = activity_map.get(data.activity_level.lower(), 0)
    creatine_adjust = data.creatine_dosage * 100
    humidity_adjust = 200 if humidity > 70 else 100 if humidity >= 50 else 0

    total_ml = round(base + temp_adjust + activity_adjust + creatine_adjust + humidity_adjust)

    # ✨ Short motivational prompt with emoji
    emoji = random.choice(["💧", "🥤", "🚰", "🫗", "🌊", "🏃‍♂️"])
    prompt = (
        f"A person weighs {data.weight}kg, is {data.gender}, exercises at a {data.activity_level} level, "
        f"takes {data.creatine_dosage}g creatine daily, and lives in {temp_c}°C with {humidity}% humidity. "
        f"{emoji} Give a unique motivational hydration tip under 15 words."
    )
    ai_advice = get_ai_advice(prompt)

    insights = [
        f"Temperature: {temp_c}°C → +{temp_adjust}ml",
        f"Humidity: {humidity}% → +{humidity_adjust}ml",
        f"Activity level: {data.activity_level} → +{activity_adjust}ml",
        f"Creatine: {data.creatine_dosage}g → +{creatine_adjust}ml"
    ]
    summary = f"Estimated daily intake: ~{total_ml} ml."

    return {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "temperature_c": temp_c,
        "humidity_percent": humidity,
        "hydration_goal_ml": total_ml,
        "insight_summary": summary,
        "insight_details": insights,
        "ai_generated_advice": ai_advice
    }
