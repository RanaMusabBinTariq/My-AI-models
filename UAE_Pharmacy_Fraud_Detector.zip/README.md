# UAE Pharmacy Fraud Detector Project

## Files Included:
- `fraud_detector.py`: Main application code
- `fraud_model.pkl`: Trained AI model
- `sample_prescriptions.csv`: Example data
- `shap_plots/`: Explanation visualizations

## How to Use:
1. Run `fraud_detector.py` 
2. Load your data
3. Call analyze_prescription() function
