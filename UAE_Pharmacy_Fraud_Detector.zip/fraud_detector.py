
# Your complete Python code from the previous cell
# (This will be replaced with the actual code when run)
